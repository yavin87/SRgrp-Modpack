# Useful keybindings
##### General
`H` toggle mod "Hold to Attack" on/off

##### Exploration
`T` create a ping at your crosshairs  
`F10` share your uncovered parts of the map  
`Left Alt + Middle Mouse` share an existing pin on your map

##### Inventory
`Del` delete mouseover item in inventory  
`Ctrl + N / H / V` sort inventory and containers by name / weight / value

##### Crafting & Building
`B` enable Build Camera when hammer is equipped
`Shift + E` on kiln, smelter, etc. to fill it completely

# Disclaimer
This modpack is intended for personal use. All credit for each mod goes to the original developer(s).
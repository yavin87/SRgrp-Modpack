# Useful keybindings
##### Exploration
`T` ping where you look  
`F10` share your map  
`Left Alt + Middle Mouse` on an existing map pin to share it with everyone

##### Inventory
`Del` delete item in inventory (mouseover)  
`Ctrl + n / h / v` sort inventory and containers by name, weight or value

##### Building & Crafting
`b` enable Build Camera when hammer is equipped
`Shift + e` on kiln, smelter, etc. to fill up (from inventory or nearby containers)

##### Misc
`h` toggle mod "Hold to Attack" on/off
`F7` toggle UI edit mode on/off

# Disclaimer
This modpack is intended for personal use. All credit for each mod goes to the original developer(s).